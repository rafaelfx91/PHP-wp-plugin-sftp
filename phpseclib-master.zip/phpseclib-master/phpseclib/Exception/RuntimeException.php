<?php

declare(strict_types=1);

namespace phpseclib3\Exception;

class RuntimeException extends \RuntimeException implements ExceptionInterface
{
}
