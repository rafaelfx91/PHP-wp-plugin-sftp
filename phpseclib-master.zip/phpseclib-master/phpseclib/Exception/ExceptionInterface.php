<?php

declare(strict_types=1);

namespace phpseclib3\Exception;

/**
 * Used to mark exceptions originating from this library.
 */
interface ExceptionInterface
{
}
